#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

	char *c = "Hello world !\n";
	printf("SO3 - Simple application\n");
	printf("%s \n", c);
	printf("%p \n", (void*) c);

	for(unsigned i = 0; i < strlen(c); ++i){

		*(unsigned int*)(0x8000 + i) += 1;

	}

	printf("%s \n", c);

	return 0;
}
