/*
 * Copyright (C) 2021 Mattia Gallacchi <mattia.gallacchi@heig-vd.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define DEBUG 0

/* Switch between memory sizes. 1 for 256B,  0 for 1024B */
#define MEMORY_SIZE_SMALL             0 // 1

/* Activate memory attributes. This is used in step 3 */
#define MEMORY_PTE_ATTRIBUTES_ACTIVE  0 // 1

/** 
 *  Defines for step 2 :
 *      MEMORY_SIZE_SMALL 1
 *      MEMORY_PTE_ATTRIBUTES_ACTIVE 0
 * 
 * Defines for step 3 :
 *      MEMORY_SIZE_SMALL 1
 *      MEMORY_PTE_ATTRIBUTES_ACTIVE 1
 * 
 * Defines for step 4 :
 *      MEMORY_SIZE_SMALL 0
 *      MEMORY_PTE_ATTRIBUTES_ACTIVE 0
 */

#if MEMORY_SIZE_SMALL
/* Number of memory pages */
#define MEMORY_PAGE_NUM         256
#define MEMORY_PAGE_SIZE        256
#else
#define MEMORY_PAGE_NUM         64
#define MEMORY_PAGE_SIZE        1024
#endif

/* Defines for step 3 */
#define VALID_BIT       (1 << 0)
#define VALID_POS       0

#define RWX_BITS        0x06
#define RWX_POS         1
#define R_PATTERN       0x01
#define W_PATTERN       0x02
#define X_PATTERN       0x03
#define RWX_PATTERN     0x00

/** 
 *  Step 3 address
 *  PADDR 8 MSB = page no.
 *  PADDR 8 LSB = [0] VALID, [2..1] RWX: 00 = ALL, 01 = R, 10: W, 11 = X
 */

#define PAGE_FAULT(addr, msg) printf("Page Fault @0x%x: %s\n", addr, msg);


uint16_t page_table[MEMORY_PAGE_NUM];

/* 256 pages of 256B or 64 pages of 4096B */
uint8_t main_mem[MEMORY_PAGE_NUM][MEMORY_PAGE_SIZE] = {0};



/**
 * @brief   Convert a virtual address to a page table entry. 
 * @param   vaddr virtual address
 * @param   pte page table entry   
 * 
 * @return  0 on success, -1 on error.
 */
int virt_to_pte(uint16_t vaddr, uint16_t *pte)
{
    int rc = -1;
    uint8_t r_shift = 0;
    uint8_t page_table_n = 0;



#if MEMORY_SIZE_SMALL
    /* TODO step 2 */
    // configuration numero de page 8 bits | offset 8 bits
    r_shift = 8;
    page_table_n = vaddr >> r_shift;
#else
    /* TODO step 4 */
    // configuration numero de page 6 bits | offset 10 bits
    r_shift = 10;
    page_table_n = vaddr >> r_shift;

#endif
    /* TODO step 2*/
    if( page_table_n < MEMORY_PAGE_NUM){
    *pte =  page_table[page_table_n];
     rc = 0;
    }

    return rc;
}

/**
 * @brief   Read a byte from memory. For step 3 also checks RWX and Valid bit.
 *          Uses virt to phys to get the physical address.
 * @param   vaddr virtual address
 * @param   byte value to read   
 * 
 * @return  0 on success, -1 on error. Page faults must use PAGE_FAULT macro to
 *          to print an error message
 */
int get_byte(uint32_t vaddr, uint8_t *byte) {

    int rc = 0;
    uint16_t offs = 0;
    uint8_t page_n = 0;
    uint16_t pte;

    rc = virt_to_pte(vaddr, &pte);
    if (rc < 0) {
        return rc;
    }

#if MEMORY_PTE_ATTRIBUTES_ACTIVE
    /* TODO step 3 : Check pte attributes*/
    uint8_t pteAtt = pte & 0xFF;

    if((((pteAtt & RWX_BITS)>> 1) != R_PATTERN ) && (((pteAtt & RWX_BITS)>> 1) != RWX_PATTERN)){
    	printf("The file can't be read\n");
    	return -1;
    }

    if((pteAtt & 0x01) != 1){ // 0000 0001
    	PAGE_FAULT(pte,"Invalid file\n");
    	return -1;
    }

#endif

#if MEMORY_SIZE_SMALL
    /* TODO step 2: page number and offset */
    // configuration numero de page 8 bits | offset 8 bits
    page_n = pte >> 8 ;
    offs = vaddr & 0xFF;
#else
    /* TODO step 4: page number and offset */
    // configuration numero de page 6 bits | offset 10 bits
    page_n = pte >> 10 ;
    offs = vaddr & 0x3FF;
#endif
    /* TODO step 2: retrieve the byte */

    if(page_n <= MEMORY_PAGE_NUM){
    	*byte = main_mem[page_n][offs] ;
     }else{
    	 rc = -1;
     }

    return rc;
}

/**
 * @brief   Write a byte to memory. For step 3 also checks RWX and Valid bit.
 *          Uses virt to phys to get the physical address.
 * @param   vaddr virtual address
 * @param   byte value to write   
 * 
 * @return  0 on success, -1 on error. Page faults must use PAGE_FAULT macro to
 *          to print an error message
 */
int store_byte(uint32_t vaddr, uint8_t byte)
{
    int rc = 0;
    uint16_t offs = 0;
    uint8_t page_n = 0;
    uint16_t pte = 0;

    rc = virt_to_pte(vaddr, &pte);
    if (rc < 0) {
        return rc;
    }

#if MEMORY_PTE_ATTRIBUTES_ACTIVE
    /* TODO step 3: Check pte attributes*/

    uint8_t pteAtt = pte & 0xFF;

    if((((pteAtt & RWX_BITS) >> 1) != W_PATTERN) && (((pteAtt & RWX_BITS) >> 1) != RWX_PATTERN)){ //0000 0100 writeonly
    	printf("The file can't be wrote\n");
    	return -1;
       }

    if((pteAtt & 0x01) != 1){ // 0000 0001
    	PAGE_FAULT(pte,"Invalid file\n");
    	return -1;
    }
#endif

#if MEMORY_SIZE_SMALL
    /* TODO step 2: page number and offset*/
    // configuration numero de page 8 bits | offset 8 bits
    offs = vaddr & 0xFF;
    page_n = pte >> 8 ;

#else
    /* TODO step 4: page number and offset */
    // configuration numero de page 6 bits | offset 10 bits
    page_n = pte >> 10 ;
    offs = vaddr & 0x3FF; // 11 1111 1111 10 bits à 1
#endif
    /* TODO step 2: store the byte */

    if(page_n <= MEMORY_PAGE_NUM){
    	main_mem[page_n][offs] = byte;
    }else{
    	rc = -1;
    }

    return rc;
}

/**
 * @brief   Prints an entire page. Can be used for debug.
 * @param   vaddr: virtual address of the page
 * @param   width: number of bytes per line (1/2/3/../32)
 */
void print_page(uint16_t vaddr, uint8_t width)
{
#if DEBUG

    uint16_t i;
    uint8_t byte;

	if (width > 32) {
		width = 32;
	}

	for (i = 0; i < MEMORY_PAGE_SIZE; ++i) {
		if (i % width == 0 && i > 0)
			printf("\n");

		if (get_byte(vaddr | i, &byte) < 0) {
			break;
		}
		printf("%02x ", byte);
	}
	printf("\n");

#else
    printf("To print activate debug\n");
#endif
}

/**
 * @brief   This function is used to test the read and write methods.
 *          !!! DO NOT MODIFY !!!
 */
int test_mem()
{
    uint8_t byte;
    int vaddr;
    int error_count = 0;

    for (vaddr = 0; vaddr < MEMORY_PAGE_NUM * MEMORY_PAGE_SIZE; ++vaddr) {
        if (get_byte(vaddr, &byte) < 0) {
            printf("Error vaddr : 0x%04x\n");
            return -1;
        }
        if (byte != (uint8_t)(vaddr & 0xFF)) {
            error_count++;
        }
    }

    if (error_count > 0) {
        printf("Memory test failed. There are %d errors\n", error_count);
        return -1;
    }
    else {
        printf("=== Memory test successfull !!!===\n");

        return 0;
    }
}

/**
 * @brief   This function is used to test the RWX and Valid bit.
 *          !!! DO NOT MODIFY !!!
 */
int test_mem_2()
{
    int i, j;
    uint16_t vaddr = 0;
    uint8_t byte = 0;

    for (i =0; i < MEMORY_PAGE_NUM; i++) {
        for (j = 0; j < MEMORY_PAGE_SIZE; j++) {
            vaddr = (i << 8) | ((j << 3) & 0xFF);

            if (i == 10 || i == 11 || i == 12) {
                /* Test read only pages*/
                if (get_byte(vaddr, &byte) < 0) {
                    printf("Readonly test failed @0x%04x\n", vaddr);
                    return -1;
                }
                if (store_byte(vaddr, 0x01) != -1) {
                    printf("Readonly test failed @0x%04x\n", vaddr);
                    return -1;
                }
                // printf("i = %d, j = %d\n", i, j);
            }
            else if (i == 5 || i== 6 || i == 7 || i == 8) {
                /* Valid bit test */
                if (get_byte(vaddr, &byte) != -1) {
                    printf("Valid bit test failed @0x%04x\n", vaddr);
                    return -1;
                }
                // printf("i = %d, j = %d\n", i, j);
            }
            else {
                if (get_byte(vaddr, &byte) < 0) {
                    printf("Readonly test failed @0x%04x\n", vaddr);
                    return -1;
                }
                if (store_byte(vaddr, 0x01) < 0) {
                    printf("Readonly test failed @0x%04x\n", vaddr);
                    return -1;
                }
            }
        }   
    }

    return 0;
}

/**
 * @brief   Initializes the page table. The virtual addresses are
 *          the inverse of the physical ones. Ex. physical 0x0000
 *          is equal to virtual 0xFFFF
 */
void init_page_table(void) {
    int i;
    uint8_t r_shift = 0;

#if MEMORY_SIZE_SMALL
    r_shift = 8;
#else
    r_shift = 10;
#endif

    for (i = 0; i < MEMORY_PAGE_NUM; ++i) {
        page_table[i] = ((MEMORY_PAGE_NUM -1) - i) << r_shift;

#if MEMORY_PTE_ATTRIBUTES_ACTIVE
        /* TODO step 3 */

        page_table[i] |= 0x01; // 0000 0001 RWX et valid bit à 1
        /* Make PTE 10 to 12 read-only */
        if(i == 10 || i == 11 || i == 12){
        	page_table[i] |= 0x02; // 0000  0010
        }

        /* Valid bit*/

        /* Make PTE 5 to 8 not valid */
        if(i == 5 || i == 6 || i == 7 || i == 8){
        	page_table[i] &= 0xFFFE; // 1111  1110
        }
#endif
    }

}

int main(int argc, char *argv[]) {    
    /*
        !!! DO NOT MODIFY the main function!!! 
    */

    init_page_table();

#if MEMORY_PTE_ATTRIBUTES_ACTIVE
    if (test_mem_2() == 0) {
        printf("===Readonly and Valid bit tests passed successfully!===\n");
    }

#else
    int vaddr;

    /** Puts data into memory */
    for (vaddr = 0; vaddr < MEMORY_PAGE_NUM * MEMORY_PAGE_SIZE; ++vaddr) {
        store_byte(vaddr, (uint8_t)(vaddr & 0xFF));
    }
    test_mem();
#endif

    /* ADD your code here for debug purpose */


    return 0;
}
