/*
 * Copyright (C) 2014-2017 Daniel Rossier <daniel.rossier@heig-vd.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/stat.h>
#include <syscall.h>
#include <time.h>
#include <stdbool.h>
#include <fcntl.h>

#define KILO_OCTET 1024
#define MEGA_OCTET KILO_OCTET * 1024
#define GIGA_OCTET MEGA_OCTET * 1024

/*
 * This function is use to retrieve atribute for the -l options
 *
 * rights represent the rights of the file or directory
 * date the last modification of the file or DIR
 * size the size of file or DIR
 * */
void findAttribute(struct stat metadata, char *rigths, char *date, char *size) {

	// retrieve rights

	if (metadata.st_mode & AM_RD) {
		rigths[0] = 'r';
	}

	if (metadata.st_mode & AM_WR) {
		rigths[1] = 'w';
	}

	if (metadata.st_mode & AM_EX) {
		rigths[2] = 'x';
	}

	// retrieve date

	struct tm *timeInfos = localtime((time_t*) &metadata.st_mtim);
	sprintf(date, "%d-%d-%d %d:%d", timeInfos->tm_year + 1900,
			timeInfos->tm_mon + 1, timeInfos->tm_mday, timeInfos->tm_hour,
			timeInfos->tm_min);

	// retrieve size
	double file_size = (double) metadata.st_size;

	if (metadata.st_size < KILO_OCTET) {

		sprintf(size, "%g%s", file_size, "B");

	} else if (metadata.st_size < MEGA_OCTET) {

		sprintf(size, "%g%s", (file_size / KILO_OCTET), "K");

	} else if (metadata.st_size < GIGA_OCTET) {

		sprintf(size, "%g%s", (file_size / MEGA_OCTET), "M");

	} else {

		sprintf(size, "%g%s", (file_size / GIGA_OCTET), "G");
	}

}



/*
 * Main function of ls application.
 * The ls application is very very short and does not support any options like -l -a etc.
 * It is only possible to give a subdir name to list the directory entries of this subdir.
 */

int main(int argc, char **argv) {
	DIR *stream;
	struct dirent *p_entry;
	char *dir;
	bool islswithoption = false;

	if (argc == 1) {

		dir = ".";

	} else if (argc == 2) {
		if (!strcmp(argv[1], "-l")) {
			dir = ".";
			islswithoption = true;
		} else {
			dir = argv[1];
		}
	} else if (argc == 3) {
		if (!strcmp(argv[1], "-l")) {
			islswithoption = true;
			dir = argv[2];
		} else if (!strcmp(argv[2], "-l")) {
			dir = argv[1];
			islswithoption = true;
		} else {
			printf("Usage: ls [DIR]\n");
			exit(1);
		}
	} else {
		printf("Usage: ls [DIR]\n");
		exit(1);
	}

	stream = opendir(dir);

	if (stream == NULL) {
		exit(1);
	}

	struct stat metadata;
	char rigths[256] = "---\0";
	char date[256];
	char size[256];
	char filename[256];
	char target[256];
	int targetFd;

	while ((p_entry = readdir(stream)) != NULL) {
		// Metadata of file

		if (stat(p_entry->d_name, &metadata) < 0)
			exit(1);

		strcpy(filename, p_entry->d_name);
		findAttribute(metadata, rigths, date, size);

		switch (p_entry->d_type) {
		/* Directory entry */
		case DT_DIR:

			if (islswithoption == false) {
				printf("%s/\n", filename);
			} else {
				printf("d%s | %s | %s | %s/\n", rigths, date, size, filename);
			}
			break;
		/* Regular entry */
		case DT_REG:
			if (islswithoption == false) {

				printf("%s/\n", filename);

			} else if (metadata.st_mode & AM_SYM) {

				if ((targetFd = open(filename, O_NOFOLLOW | O_PATH)) < 0) {
					return -1;
				}
				if (read(targetFd, target, 256) < 0) {
					return -1;
				}
				if (close(targetFd) < 0) {
					return -1;
				}
				printf("l%s | %s | %s | %s -> %s\n", rigths, date, size,
						filename, target);
			} else
				printf("-%s | %s | %s | %s\n", rigths, date, size, filename);
			break;

		default:
			break;
		}
	}
	exit(0);
}

