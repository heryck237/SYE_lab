#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
	if (argc != 3)
		return 0;

	int fd = open(argv[1], O_RDONLY);

	if (fd < 0) {
		return -1;
	}

	// no error check because according to the sys_symlink description, it doen't return -1 if error.
	sys_symlink(fd, argv[2]);

	return 0;
}
