#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <syscall.h>
#include <pthread.h>
#include <string.h>

#define COUNT 100
#define MAXIMUM_THREAD 15

/**
 * @brief Function that execute the count
 * @param args The name of the thread
 * @return NULL
 */
void *count(void *args)
{


	int th_id = *(int *)args;
	 size_t i;

    for(i = 0; i <= COUNT ; ++i){

        fprintf(stdout," Thread %d: %zu\n", th_id , i);
    }


    return NULL ;

}

/**
 * @brief Launches N parallel threads
 * @param num_of_threads Number of threads to be launched
 */
void parallel_threads_launch(int num_of_threads)
{

	pthread_t thread[num_of_threads] ;
	int  th_id[num_of_threads];

	for(int i=0 ; i < num_of_threads ; ++i){
		th_id[i] = i ;

		if(pthread_create(&thread[i], NULL, count ,&th_id[i])){
			printf("Error while creating thread %d\n",th_id[i]);
			exit(EXIT_FAILURE);
		}
	}

	for(int i=0 ; i < num_of_threads ; ++i){

		pthread_join(thread[i], NULL);
	}
}

/**
 * @brief Launches N sequential threads
 * @param num_of_threads Number of threads to be launched
 */
void sequential_threads_launch(int num_of_threads)
{

	pthread_t thread[num_of_threads] ;
	int th_id[num_of_threads];


	for(int i=0 ; i < num_of_threads ; ++i){
		th_id[i] = i;
		if(pthread_create(&thread[i], NULL, count , &th_id[i])){
			printf("Error while creating thread %d\n",th_id[i]);
			exit(EXIT_FAILURE);
		}
		pthread_join(thread[i], NULL);
	}




}

/**
 * @brief Main function
 */
int main(int argc, char **argv)
{
	if(argc != 3){
		printf("Usage : %s <N> [p|s]\n", argv[0]);

	}
	int nbThread = atoi(argv[1]);

	if(nbThread > 0 && nbThread < MAXIMUM_THREAD){

		if( !strcmp(argv[2], "p")){

			parallel_threads_launch(nbThread);

		}else if( !strcmp(argv[2], "s")){

			sequential_threads_launch(nbThread);

		}else{

			printf(" argv[2] should be [p|s]\n");
		}

	}else{

		printf("The number of threads should be more than 0  and less than 15\n");

	}

	return EXIT_SUCCESS;

}
