#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>


#include "tictactoe_priv.h"

/* Private struct */
sye_ipc_t ipc;

extern int errno;


/**
 * @brief   Parse a string with the index of the cell to select.
 *
 * @param str   String to parse
 * @param index Index of the cell
 *
 * @returns 1 if the string format is correct, 0 otherwise.
 */



/**
 * @brief Create the pipes and save the file descriptors in the ipc struct
 * @return 0;
 */
int ipc_init(void) {

	int errNum, num;

	/* create a pipe for the player */
	num = pipe(ipc.pipe1);

	if(num < 0){
		errNum = errno;
		fprintf(stderr, "pipe creation failed: %d\n", errNum);
		exit(errNum);
	}

    ipc.gm_recv  = ipc.pipe1[0];
    ipc.player_send = ipc.pipe1[1];

	/* create a pipe for game manager */
	num = pipe(ipc.pipe2);

	if(num < 0){
		errNum = errno;
		fprintf(stderr, "pipe creation failed: %d\n", errNum);
		exit(errNum);
	}
    ipc.player_recv = ipc.pipe2[0];
    ipc.gm_send  = ipc.pipe2[1];




	return 0;
}

/**
 * @brief Initializes the player file descriptors
 * @param argv The 2 file descriptors for the child process
 */
int ipc_init_child(char **argv) {

	ipc.player_recv = atoi(argv[1]);
	ipc.player_send = atoi(argv[2]);

	return 0;
}

/**
 * @brief Closes all open pipes
 */
void ipc_close(void) {

	close(ipc.pipe1[READ_SIDE]);
	close(ipc.pipe1[WRITE_SIDE]);
	close(ipc.pipe2[READ_SIDE]);
	close(ipc.pipe2[WRITE_SIDE]);
}

/**
 * @brief Reads the pipe used to communicate from the player to the game manager
 * @return -1 if error, command value otherwise
 */
int gm_get_cmd(void) {

	int  errNum;
	ssize_t num ;
	int move;

	num = read(ipc.gm_recv, &move, MAX_BUFFER_LENGTH);

    if (num < 0) {
    	errNum = errno;
    	fprintf(stderr, "Reading failed: %d\n", errNum);
    	exit(errNum);
      }

    return move;

}


 /**
 * @brief Writes the pipe used to communicate from the the game manager to the player
 * @return -1 if error, 0 otherwise
 */
int gm_send_cmd(int cmd) {

	int errNum ;
	ssize_t num;

	num = write(ipc.gm_send , &cmd , CMD_SIZE);

		if(num < 0){
			errNum = errno;
			fprintf(stderr, "writing failed: %d\n", errNum);
			exit(errNum);
		}

	return  0;

}

/**
 * @brief Reads the pipe used to communicate from the game manager to the player
 * @return -1 if error, command value otherwise
 */
int player_get_cmd(void) {

	int  errNum;
	ssize_t num;
	int move;

	num = read(ipc.player_recv, &move, MAX_BUFFER_LENGTH);

    if (num < 0) {
    	errNum = errno;
    	fprintf(stderr, "Reading failed: %d\n", errNum);
    	exit(errNum);
      }


    return move;


}

/**
* @brief Writes the pipe used to communicate from the the player to the game manager
* @return -1 if error, 0 otherwise
*/
int player_send_cmd(int cmd) {

	int errNum ;
	ssize_t num;

	num = write(ipc.player_send , &cmd, CMD_SIZE);

	if(num < 0){
		errNum = errno;
		fprintf(stderr, "writing failed: %d\n", errNum);
		exit(errNum);
	}

	return  0;

}

/**
 * @brief Get player receiving pipe file descriptor
 * @return Pipe file descriptor
 */
int ipc_player_argv1(void) {

	return ipc.player_recv;
}

/**
 * @brief Get player writing pipe file descriptor
 * @return Pipe file descriptor
 */
int ipc_player_argv2(void) {

return ipc.player_send;

}
