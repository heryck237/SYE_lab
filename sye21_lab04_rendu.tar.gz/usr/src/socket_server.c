/*
 * Copyright (C) 2021 David Truan <david.truan@heig-vd.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
 #include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdbool.h>

#include "socket_sye.h"

int main(int argc, char *argv[]) {

    /* A COMPLETER: déclarations des variables */
    int running = 1;
    int contentsnd = 0, contentrcv = 0;
    int counter = 0;
    int listenfd = 0, connfd = 0;
    struct sockaddr_in serv_addr;
    struct sockaddr_in client_addr;
    char sendBuff[80];
    char recvBuff[80];
 	char addr[INET_ADDRSTRLEN];
    bool closeCon = false;

    /* A COMPLETER: Mise en place du socket et connexion avec le client */

     listenfd = socket(AF_INET, SOCK_STREAM, 0);
     memset(&serv_addr, 0, sizeof(serv_addr));


     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
     serv_addr.sin_port = htons(5000);

     bind(listenfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr));

     listen(listenfd, 10);


   	printf("Waiting for clients...\n");

   	int addrlen = sizeof(client_addr);

 	connfd = accept(listenfd, (struct sockaddr *)&client_addr ,(socklen_t *)&addrlen);

 	inet_ntop( AF_INET, &client_addr.sin_addr, addr, sizeof( addr ));

 	printf("Client connected!\n");

    /* Boucle de traitement principal. C'est ici que la reception des message 
        et l'envoi des réponses se font. */
    while (running) {
        /* A COMPLETER: Reception et traitement des messages */


            memset(sendBuff, 0, sizeof(sendBuff));
            memset(recvBuff, 0, sizeof(recvBuff));

    		contentrcv = read(connfd, recvBuff, sizeof(recvBuff)-1);
//
//    		if(contentrcv < 0){
//    			printf(" Read error \n");   // S'affiche en continu dans la console
//    		}

    		if(!strcmp(recvBuff,"Bonjour\n")){
    			sprintf(sendBuff,"%s %s\n", "Bonjour client" ,  addr);
    		}else if(!strcmp(recvBuff, "Aurevoir\n")){
    			sprintf(sendBuff,"%s %s\n", "Aurevoir client" ,  addr);
    		}else if(!strcmp(recvBuff, "Compteur\n")){
    			++counter;
    			sprintf(sendBuff,"%s %d\n", "Valeur compteur ", counter);

    		}else if(!strcmp(recvBuff, "Quitter\n")){
    			closeCon = true;
    		}else{
    			continue;
    		}

    		printf("The client said: %s\n", recvBuff);



    		if(closeCon){
    			 printf("The client asked for a disconnection, now quitting...\n");
    			 running = 0;
    		}


    	     /* A COMPLETER: Envoi de la réponse */
    		contentsnd = write(connfd, sendBuff, sizeof(sendBuff));
    		if(contentsnd < 0){
    			printf("Write error\n");
    		}



    }


    /* A COMPLETER: Nettoyage des ressources*/

	 close(listenfd);
   	 close(connfd);

    return 0;

}
