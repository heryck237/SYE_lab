/*
 * Copyright (C) 2021 David Truan <david.truan@heig-vd.ch>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "socket_sye.h"


#define BUFFER_LEN  80

static int nbenvoie = 1;

/* Variable de "routage" */
msg_idx_t message_to_send = 0;

/* A COMPLETER: Handlers des signaux */

void process_sig(int sig_number){

	switch(sig_number){

	case SIGUSR1 :
		message_to_send = GREETING;
		nbenvoie++;
		printf("Handler USR1\n");
	break;
	case SIGUSR2 :
		message_to_send = COUNTING;
		printf("Handler USR2\n");
	break;
	default:
		printf("default\n");
		break;

	}

}

void process_sigint(int sig_number){

	if(SIGINT == sig_number){

		message_to_send = QUITING;
	    printf("Handler INT\n");

	}

}

int main(int argc, char **argv) {
    /* A COMPLETER: Variables */
    int running = 1;
    int sockfd ;
    char recvBuff[BUFFER_LEN], buffersnd[BUFFER_LEN];;
    struct sockaddr_in serv_addr;


    /* A COMPLETER: Traitement des arguments */

    char addr[80];
    strcpy(addr,argv[1]);

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Error : Could not create socket \n");
        return 1;
    }

        memset(&serv_addr, 0, sizeof(serv_addr));

        serv_addr.sin_family = AF_INET;
        serv_addr.sin_port = htons(5000);

        if (inet_pton(AF_INET, argv[1], &serv_addr.sin_addr)<=0)
        {
            printf("\n inet_pton error occured\n");
            return 1;
        }




    /* A COMPLETER: Liens entre signaux et handlers */

    signal(SIGUSR1,process_sig);
    signal(SIGUSR2,process_sig);
    signal(SIGINT,process_sigint);

    /* A COMPLETER: Création du socket et connection au serveur */
    if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
     {
        printf("\n Error : Connect Failed \n");
        return 1;
     }
     fprintf(stdout, "Connecting to server at %s:%d... SUCCESS\n", addr,PORT);
     fflush(stdout);

    while (running) {
        /* buffer de reception */
        memset(recvBuff, 0, sizeof(recvBuff));
        memset(buffersnd, 0, sizeof(buffersnd));

        int n = 0;

        /* A COMPLETER: Préparation en envoi du message */
        switch (message_to_send) {

        case GREETING  :

        	if(nbenvoie % 2 == 0){
        		strcpy(buffersnd,"Bonjour\n");
        	}else{
        		strcpy(buffersnd,"Aurevoir\n");

        	}
        break;
        case COUNTING : strcpy(buffersnd,"Compteur\n");
        	break;
        case QUITING  : strcpy(buffersnd,"Quitter\n");
        				running = 0 ;
        	break;

        default :
        	continue;

        }

        message_to_send = 0;
        write(sockfd, buffersnd, sizeof(buffersnd));
       // fflush(sockfd);


        /* A COMPLETER: Réception, si nécessaire de la réponse */

        while((n = read(sockfd, recvBuff, sizeof(recvBuff)-1)) < sizeof(recvBuff)-1) ;
//
//        if (n < 0)
//        {
//            printf("\n Read error \n"); // pas necessaire car on lit jusqu'a BUFFER_LEN
//        }

        fprintf(stdout, "%s\n",recvBuff);
        fflush(stdout);
    }



    /* A COMPLETER: Nettoyage des ressources */
    close(sockfd);

    return 0;
}
