#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
#include <syscall.h>

#define MAX_PROCESSUS 15

void sequentiel(int arg) {
	pid_t pid;
	int id = 0;
	char arg2[3] = { 0 }; // 3 pour 15\n

	for (int i = 0; i < arg; ++i) {
		id = i;
		sprintf(arg2, "%d", id);
		pid = sys_fork2();
		if (pid) {
			waitpid(pid, NULL, 0);

		} else {

			if(execl("count.elf", "count", arg2, NULL) < 0)
			exit(0);
		}

	}
}

void parallel(int arg) {

	int id = 0;
	char arg2[3] = { 0 }; // 3 pour 15\n
	pid_t tabPid[15];

	for (int i = 0; i < arg; ++i) {
		id = i;
		sprintf(arg2, "%d", id);
		tabPid[i] = sys_fork2();


		if(!tabPid[i]){
		 if(execl("count.elf", "count", arg2, NULL) < 0)
		    exit(0);
		}

	}

	for (int i = 0; i < arg; ++i) {
		if (tabPid[i]) {
			waitpid(tabPid[i], NULL, 0);
		}

	}
}

int main(int argc, char **argv) {

	if (argc != 3) {
		printf("Usage: %s <N> [p|s]\n", argv[0]);
		return 1;
	}

	int arg = atoi(argv[1]);

	if (arg > 0 && arg <= MAX_PROCESSUS) {

		if (!strcmp(argv[2], "s")) {

			sequentiel(arg);

		} else if (!strcmp(argv[2], "p")) {

			parallel(arg);
		} else {
			printf("argv[2] should be [p|s]\n");
		}

	} else {
		printf("argv[1] should be greater than 0 and less than 15 \n");

	}

	return EXIT_SUCCESS;
}
