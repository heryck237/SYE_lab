# SYE 2021 - Laboratoire 02

## Explication du cheminement pour l'ajout d'un appel système dans SO3

- Etape 1 :  definition du numero de l'appel systeme dans le fichier so3/arch/arm32/include/  § asm/syscall.h : #define SYSCALL_FORK2     120 
- Etape 2 :  declaration de la fonction de l'appel systeme dans so3/include/process.h : int    do_fork2(void);
- Etape 3 : definition de cette fonction dans so3/kernel/process.c par copie de do_fork() original.
- Etape 4 : Dans  so3/kernel/syscalls.c, ajouter un case dans le syscall_handle()  lui indiquant la fonction à executer pour un appel systeme du numero correspondant au syscall_fork2.
- Etape 5 : Dans le usr/lib/libc/include/syscall.h ,  ajouter #define syscallFork2	 120 . definit le code de l'appel système côté utilisateur, pour indiquer au noyau quel appel système effectuer.
- Etape 6 : Dans le fichier usr/lib/libc/crt0.S nous avons ajouter : SYSCALLSTUB sys_fork2, 			syscallFork2
            sys_fork2() peut désormais être appelé côte utilisateur pour lancer un appel système  


