#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <syscall.h>

int main(int argc, char **argv) {
    // TO COMPLETE


	void* memoryBlock = malloc(4096);

	if(!memoryBlock){
		printf("Allocation error\n");
	}
	printf("Virtual address : %u\n", memoryBlock);
	printf("Physical address : %u\n",sys_translate((uint32_t)memoryBlock));

	free(memoryBlock);

    return 0;
}
