# SYE 2021 - Laboratoire 06

## Appel système `renice` et gestion des priorités

1. **Lancer l’application « time_loop » en arrière-plan (avec le symbole &) depuis le shell. Que se passe-t-il et pourquoi ?**

    Réponse : l'application est lancé mais ne s'exécute pas car on la lance en arrière plan, du coup même en ayant la même priorité , le shell devient plus prioritaire.   

2. **Changer la priorité du shell pour que le processus « time_loop » deviennent plus prioritaire. Que se passe-t-il et pourquoi ?**

    Réponse : en faisant un renice 1 5 pour mettre la priorité du shell plus petite que celle du time loop , l'execution se lance directement.


## Gestion de la mémoire

1. **Dans le noyau, où se trouve le code gérant l'allocation dynamique de la mémoire (gestion du tas) ?**

    Réponse : dans so3/mm/heap.c

2. **Quel est l'algorithme de gestion mémoire utilisé dans ce contexte ?**

    Réponse : Quick Fit d'après le code qui se trouve dans heap.c

3. **Dans le noyau, où se trouve le code de la gestion de la MMU ?**

    Réponse :  so3/arch/arm32/mmu.c

4. **Exécuter plusieurs fois l’application `memory`. Que constate-on au niveau des adresses physique et virtuelle ? Pourquoi ?**

    Réponse : On constate que l'adresse virtuelle reste la même tandis que l'adresse physique change. Ceci est dû au fait que un programme pour se lancer a besoin d'une adresse fixe dans laquelle son code pourra être cherché, ceci est l'adresse virtuelle, lorsque le code est exécuté cette adresse est traduite en adresse physique, et il peut être mis à n'importe quelle adresse physique à chacune de ses exécutions moyennant qu'il y ait l'espace dont on besoin.
 